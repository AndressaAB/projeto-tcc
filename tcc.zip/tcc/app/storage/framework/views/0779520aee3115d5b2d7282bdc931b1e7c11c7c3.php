<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">
  <link href="<?php echo asset('css/style-login.css'); ?>" rel="stylesheet">

</head>

<body>
  <div id="login-page" class="row">
    <div class="col s12 z-depth-6 card-panel">
      
      <?php echo Form:: open (['route' =>'user.login', 'method'=> 'post']); ?>


        <div class="row">
          <div class="input-field col s12 center">
            <p class="center login-form-text" style="font-weight: bolder; font-size: 1.3em;">Bem vindo!</p>
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-social-person-outline prefix"></i>
             <?php echo e(Form:: text ('email', null, ['class' =>'input', 'placeholder'=> 'E-mail'])); ?>

            <label for="email" data-error="wrong" data-success="right" class="center-align">Email</label>
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
            <?php echo Form:: password ('password', ['placeholder'=> 'Senha']); ?>

            <label for="password">Senha</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12 m12 l12  login-text">
              <input type="checkbox" id="remember-me" />
              <label for="remember-me">Lembre-se de mim!</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
            <?php echo Form:: submit ('Entrar'); ?>

            <!-- <input type="submit" value="Enter" class="btn waves-effect waves-light col s12" style="background-color: #42b984;"/> -->
          </div>
        </div>
        <div class="row">
          <div class="input-field col s6 m6 l6">
            <p class="margin medium-small"><a href="register.html">Ainda não tem cadastro?</a></p>
          </div>
          <div class="input-field col s6 m6 l6">
              <p class="margin right-align medium-small"><a href="forgot-password.html">Esqueceu sua senha?</a></p>
          </div>
        </div>

      <?php echo Form::close(); ?>

    </div>
  </div>
  <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>

</body>

</html>